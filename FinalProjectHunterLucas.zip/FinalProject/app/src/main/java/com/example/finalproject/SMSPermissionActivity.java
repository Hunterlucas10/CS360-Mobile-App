package com.example.finalproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        TextView smsPermissionText = findViewById(R.id.smsPermissionText);
        Button requestPermissionButton = findViewById(R.id.requestPermissionButton);
        Button denyPermissionButton = findViewById(R.id.permissionGoBack);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsPermissionText.setText("SMS permission is already granted.");
            requestPermissionButton.setEnabled(false);
        } else {
            smsPermissionText.setText("Inventory App requires permission to send SMS notifications.");
            requestPermissionButton.setEnabled(true);
        }

        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(SMSPermissionActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            }
        });
        denyPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceedToInventoryGrid(false);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                proceedToInventoryGrid(true);
            } else {
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
                proceedToInventoryGrid(false);
            }
        }
    }

    private void proceedToInventoryGrid(boolean isPermissionGranted) {
        Intent intent = new Intent(SMSPermissionActivity.this, InventoryActivity.class);
        intent.putExtra("isPermissionGranted", isPermissionGranted);
        startActivity(intent);
        finish();
    }
}