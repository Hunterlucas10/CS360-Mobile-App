package com.example.finalproject;

import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private GridLayout inventoryGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        dbHelper = new DatabaseHelper(this);
        inventoryGrid = findViewById(R.id.inventoryGrid);

        loadInventoryItems();

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addInventoryItem("New Item", 0, "2025-04-19");
            }
        });
    }

    private void loadInventoryItems() {
        inventoryGrid.removeAllViews();
        createHeaderRow();
        Cursor cursor = dbHelper.getAllInventoryItems();

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                int itemNameIndex = cursor.getColumnIndex("item_name");
                int quantityIndex = cursor.getColumnIndex("quantity");
                int lastActionDateIndex = cursor.getColumnIndex("last_action_date");
                int idIndex = cursor.getColumnIndex("id");

                if (itemNameIndex != -1 && quantityIndex != -1 && lastActionDateIndex != -1 && idIndex != -1) {
                    String itemName = cursor.getString(itemNameIndex);
                    int quantity = cursor.getInt(quantityIndex);
                    String lastActionDate = cursor.getString(lastActionDateIndex);
                    int id = cursor.getInt(idIndex);

                    createItemRow(id, itemName, quantity, lastActionDate);
                } else {
                    Toast.makeText(InventoryActivity.this, "Error: Invalid column index", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        } else {
            Toast.makeText(InventoryActivity.this, "No inventory items found.", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
    }

    private void createHeaderRow() {
        addTextViewToGrid("Item Name", true);
        addTextViewToGrid("Quantity", true);
        addTextViewToGrid("Last Action", true);
        addTextViewToGrid("Action", true);
    }
    private void createItemRow(int id, String itemName, int quantity, String lastActionDate) {
        addTextViewToGrid(itemName, false);
        addTextViewToGrid(String.valueOf(quantity), false);
        addTextViewToGrid(lastActionDate, false);
        addDeleteButtonToGrid(id);
    }
    private void addTextViewToGrid(String text, boolean isHeader) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(Gravity.CENTER);
        if (isHeader) {
            textView.setTextSize(18);
            textView.setBackgroundResource(R.drawable.border);
        }
        inventoryGrid.addView(textView);
    }
    private void addDeleteButtonToGrid(final int id) {
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setPadding(8, 8, 8, 8);
        deleteButton.setGravity(Gravity.CENTER);
        deleteButton.setBackgroundResource(R.drawable.border);

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isDeleted = dbHelper.deleteInventoryItem(id);
                if (isDeleted) {
                    Toast.makeText(InventoryActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                    loadInventoryItems();
                } else {
                    Toast.makeText(InventoryActivity.this, "Error deleting item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        inventoryGrid.addView(deleteButton);
    }

    private void addInventoryItem(String itemName, int quantity, String lastActionDate) {
        boolean isItemAdded = dbHelper.addInventoryItem(itemName, quantity, lastActionDate);
        if (isItemAdded) {
            Toast.makeText(InventoryActivity.this, "Item added", Toast.LENGTH_SHORT).show();
            loadInventoryItems();
        } else {
            Toast.makeText(InventoryActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }
}