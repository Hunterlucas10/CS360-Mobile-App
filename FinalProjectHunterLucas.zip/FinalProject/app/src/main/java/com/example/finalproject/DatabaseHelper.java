package com.example.finalproject;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "appDatabase.db";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_USERS_TABLE = "CREATE TABLE users (" +
            "username TEXT PRIMARY KEY," +
            "password TEXT" +
            ");";

    private static final String CREATE_INVENTORY_TABLE = "CREATE TABLE inventory (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "item_name TEXT," +
            "quantity INTEGER," +
            "last_action_date TEXT" +
            ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return isValid;
    }

    public boolean addInventoryItem(String itemName, int quantity, String lastActionDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("last_action_date", lastActionDate);

        long result = db.insert("inventory", null, values);
        db.close();
        return result != -1;
    }

    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM inventory";
        return db.rawQuery(query, null);
    }

    public boolean updateInventoryItem(int id, String itemName, int quantity, String lastActionDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("last_action_date", lastActionDate);

        int result = db.update("inventory", values, "id = ?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("inventory", "id = ?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }
}